package app.ps.sre

import br.com.zgsolucoes.ps.sre.HealthcheckController
import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class HealthcheckControllerSpec extends Specification implements ControllerUnitTest<HealthcheckController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
