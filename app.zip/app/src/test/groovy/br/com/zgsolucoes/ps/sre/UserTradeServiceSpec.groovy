package br.com.zgsolucoes.ps.sre

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class UserTradeServiceSpec extends Specification implements ServiceUnitTest<UserTradeService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
