package br.com.zgsolucoes.ps.sre

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class UserTradeControllerSpec extends Specification implements ControllerUnitTest<UserTradeController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
