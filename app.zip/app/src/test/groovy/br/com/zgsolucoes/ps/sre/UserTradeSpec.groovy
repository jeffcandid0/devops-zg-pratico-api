package br.com.zgsolucoes.ps.sre

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class UserTradeSpec extends Specification implements DomainUnitTest<UserTrade> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
