package br.com.zgsolucoes.ps.sre

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class InstrumentQuoteSpec extends Specification implements DomainUnitTest<InstrumentQuote> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
