package br.com.zgsolucoes.ps.sre

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class InstrumentQuoteControllerSpec extends Specification implements ControllerUnitTest<InstrumentQuoteController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
