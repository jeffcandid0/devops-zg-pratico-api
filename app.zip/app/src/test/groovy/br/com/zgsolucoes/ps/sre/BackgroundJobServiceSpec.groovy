package br.com.zgsolucoes.ps.sre

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class BackgroundJobServiceSpec extends Specification implements ServiceUnitTest<BackgroundJobService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
